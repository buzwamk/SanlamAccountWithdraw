package SanlamBankAccount.withdrwal.Event;

import SanlamBankAccount.withdrwal.model.WithdrawalEvent;
import tools.jackson.databind.ObjectMapper;

public class SnsWithdrawalEventPublisher implements WithdrawalEventPublisher {

    @Override
    public void publish(WithdrawalEvent event) {
        try {
            ObjectMapper objectMapper = null;
            String eventJson = objectMapper.writeValueAsString(event);

            String snsTopicArn = "arn:aws:sns:YOUR_REGION:YOUR_ACCOUNT_ID:YOUR_TOPIC_NAME";
            PublishRequest publishRequest = PublishRequest.builder()
                    .message(eventJson)
                    .topicArn(snsTopicArn)
                    .build();
            PublishResponse publishResponse = snsClient.publish(publishRequest);

        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Failed to serialize withdrawal event", e);
        }
    }
}
