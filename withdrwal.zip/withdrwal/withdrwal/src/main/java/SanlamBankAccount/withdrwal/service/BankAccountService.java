package SanlamBankAccount.withdrwal.service;

import SanlamBankAccount.withdrwal.Event.WithdrawalEventPublisher;
import SanlamBankAccount.withdrwal.model.WithdrawalEvent;
import SanlamBankAccount.withdrwal.model.WithdrawalResult;
import SanlamBankAccount.withdrwal.model.WithdrawalStatus;
import SanlamBankAccount.withdrwal.repository.BankAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Service
@Component
public class BankAccountService {

    private static final Logger log = LoggerFactory.getLogger(BankAccountService.class);

    private final BankAccountRepository bankAccountRepository;


    public BankAccountService(BankAccountRepository bankAccountRepository) {
        this.bankAccountRepository = bankAccountRepository;
    }

    @Transactional
    public WithdrawalResult withdraw(Long accountId, BigDecimal amount) {
        validate(accountId, amount);

        String transactionId = UUID.randomUUID().toString();

        boolean accountExists = bankAccountRepository.existsById(accountId);
        if (!accountExists) {
            log.warn("Withdrawal rejected. accountId={}, amount={}, reason=ACCOUNT_NOT_FOUND, txId={}",
                    accountId, amount, transactionId);
            return WithdrawalStatus.ACCOUNT_NOT_FOUND;
        }

        int rowsUpdated = bankAccountRepository.withdrawFromtBalance(accountId, amount);

        if (rowsUpdated == 0) {
            log.warn("Withdrawal rejected. accountId={}, amount={}, reason=INSUFFICIENT_FUNDS, txId={}",
                    accountId, amount, transactionId);
            return WithdrawalStatus.INSUFFICIENT_FUNDS;
        }

        WithdrawalEvent event = new WithdrawalEvent(
                accountId,
                amount,
                "SUCCESSFUL",
                Instant.now()
        );

        WithdrawalEventPublisher.publish(event);

        log.info("Withdrawal successful. accountId={}, amount={}, txId={}",
                accountId, amount, transactionId);

        return WithdrawalStatus.SUCCESS;
    }

    private void validate(Long accountId, BigDecimal amount) {
        if (accountId == null) {
            throw new IllegalArgumentException("accountId must not be null");
        }
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("amount must be greater than zero");
        }
    }





}
