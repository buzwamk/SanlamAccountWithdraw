package SanlamBankAccount.withdrwal.Event;

import SanlamBankAccount.withdrwal.model.WithdrawalEvent;

public interface WithdrawalEventPublisher {

    static void publish(WithdrawalEvent event);
}
