package SanlamBankAccount.withdrwal.repository;

import SanlamBankAccount.withdrwal.service.BankAccountService;
import org.springframework.data.repository.CrudRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class BankAccountRepository {
    private final JdbcTemplate jdbcTemplate;

    public BankAccountRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public boolean existsById(Long accountId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM accounts WHERE id = ?",
                Integer.class,
                accountId
        );
        return count != null && count > 0;
    }

    public int withdrawFromtBalance(Long accountId, BigDecimal amount) {
        return jdbcTemplate.update(
                """
                        UPDATE accounts
                           SET balance = balance - ?
                         WHERE id = ?
                           AND balance >= ?
                        """,
                amount, accountId, amount
        );
    }

}
