package SanlamBankAccount.withdrwal.model;

import java.math.BigDecimal;
import java.time.Instant;

public class WithdrawalEvent {

    private BigDecimal amount;
    private Long accountId;
    private String status;
    public WithdrawalEvent(BigDecimal amount, Long accountId, String status) {
        this.amount = amount;
        this.accountId = accountId;
        this.status = status;
    }

    public WithdrawalEvent(Long accountId, BigDecimal amount, String successful, Instant now) {
    }

    public BigDecimal getAmount() {
        return amount;
    }
    public Long getAccountId() {
        return accountId;
    }
    public String getStatus() {
        return status;
    }
    // Convert to JSON String
    public String toJson() {
        return String.format("{\"amount\":\"%s\",\"accountId\":%d,\"status\":\"%s\"}", amount, accountId, status);
    }
}
