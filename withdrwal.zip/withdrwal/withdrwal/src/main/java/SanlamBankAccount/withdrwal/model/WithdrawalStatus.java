package SanlamBankAccount.withdrwal.model;

public enum WithdrawalStatus {
    SUCCESS,
    INSUFFICIENT_FUNDS,
    ACCOUNT_NOT_FOUND
}
