package SanlamBankAccount.withdrwal.model;

public class WithdrawalResult {

    private final WithdrawalStatus status;

    public WithdrawalResult(WithdrawalStatus status) {
        this.status = status;
    }

    public WithdrawalStatus status() {
        return status;
    }

}
