package SanlamBankAccount.withdrwal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithdrwalApplication {

	public static void main(String[] args) {
		SpringApplication.run(WithdrwalApplication.class, args);
	}

}
