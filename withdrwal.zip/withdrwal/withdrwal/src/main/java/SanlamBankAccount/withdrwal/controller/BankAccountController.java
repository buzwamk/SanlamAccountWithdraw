package SanlamBankAccount.withdrwal.controller;

import SanlamBankAccount.withdrwal.model.WithdrawalResult;
import SanlamBankAccount.withdrwal.model.WithdrawalStatus;
import SanlamBankAccount.withdrwal.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
@RequestMapping("/bank")

public class BankAccountController {

    @Autowired
    BankAccountService  bankAccountService;
    @PostMapping("/withdraw")
    public ResponseEntity<?> withdraw(
            @RequestParam Long accountId,
            @RequestParam BigDecimal amount) {

        WithdrawalResult result = bankAccountService.withdraw(accountId, amount);

        if (result.status() == WithdrawalStatus.SUCCESS) {
            return ResponseEntity.ok("Withdrawal successful");
        }

        if (result.status() == WithdrawalStatus.INSUFFICIENT_FUNDS) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Insufficient funds");
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Account not found");
    }


}

